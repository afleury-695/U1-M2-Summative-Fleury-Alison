public class Warrior extends Character{

    //unique property of warrior
    protected int shieldStrength = 100;

    //unique method of warrior
    public void decreaseShieldStrength() {
        System.out.println("Shield strength decreased.");

    }

    //getter and setter so we can call shieldStrength and print it as an attribute of this guy!
    public int getShieldStrength() {
        return shieldStrength;
    }

    public void setShieldStrength(int shieldStrength) {
        this.shieldStrength = shieldStrength;
    }
}
