public class Farmer extends Character {


        public void harvest () {
            System.out.println("Harvested.");
        }

        public void plow () {
            System.out.println("Plowed.");
        }
    }

