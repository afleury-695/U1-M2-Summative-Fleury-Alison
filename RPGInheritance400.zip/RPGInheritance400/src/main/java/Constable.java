public class Constable extends Character {

    public void arrest() {
        System.out.println("Arrested.");
    }
}
