public class Character {


    protected String name;
    protected int strength;
    protected int health;
    protected int stamina;
    protected int speed;
    protected int attackPower;


    //all the shared methods!
    public void run() {
        System.out.println("Ran.");
    }

    public void heal() {
        System.out.println("Healed.");
    }

    public void attack() {
        System.out.println("Attacked.");
    }

    public void decreaseHealth() {
        System.out.println("Health decreased.");
    }


    public void increaseStamina() {
        System.out.println("Stamina increased.");
    }


    public void decreaseStamina() {
        System.out.println("Stamina decreased.");
    }

    public void set_values(String a, int b, int c, int d, int e, int f) {
        name = a;
        strength = b;
        health = c;
        stamina = d;
        speed = e;
        attackPower = f;
    }

}
