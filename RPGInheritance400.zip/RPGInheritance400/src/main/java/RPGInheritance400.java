public class RPGInheritance400 {

    public static void main(String[] args) {

        //HEADER
        System.out.println("NEW FARMER");
        System.out.println("\n");
        //new farmer
        Farmer farmer1 = new Farmer();

        //inherit the values and set them using set_values method called from Character, then print them to console to show inherited stats / other stats depending on the object
        farmer1.set_values("Farmer John", 75, 100, 75, 10, 1);
        System.out.println("Name: " +  farmer1.name + "\n");
        System.out.println("Strength: " +  farmer1.strength + "\n");
        System.out.println("Health: " +  farmer1.health + "\n");
        System.out.println("Stamina: " +  farmer1.stamina + "\n");
        System.out.println("Speed: " +  farmer1.speed + "\n");
        System.out.println("Attack Power: " +  farmer1.attackPower + "\n");

    //I set my methods just to print the action they're running to show they inherit here (I had a scripted RPG, but when my computer freaked out it emptied the whole file, so in the interest of time.
        System.out.println("\n" + "Running the new Farmer's methods: " + "\n");
        //running farmer-specific methods
        farmer1.plow();
        farmer1.harvest();

        //normal methods to show that we inherited these from character
        farmer1.attack();
        farmer1.run();
        farmer1.heal();
        farmer1.decreaseHealth();
        farmer1.increaseStamina();
        farmer1.decreaseStamina();

        //header for console
        System.out.println("\n");
        System.out.println("NEW CONSTABLE");
        System.out.println("\n");

        //new Constable
        Constable constable1 = new Constable();
        //using set_values
        constable1.set_values("Constable John", 60, 100, 60, 20, 5);
        //print to console
        System.out.println("Name: " +  constable1.name + "\n");
        System.out.println("Strength: " +  constable1.strength + "\n");
        System.out.println("Health: " +  constable1.health + "\n");
        System.out.println("Stamina: " +  constable1.stamina + "\n");
        System.out.println("Speed: " +  constable1.speed + "\n");
        System.out.println("Attack Power: " +  constable1.attackPower + "\n");


        System.out.println("\n" + "Running the new Constable's methods: " + "\n");
        //constable methods
        constable1.arrest();

        //normal methods to show that we inherited these from character
        constable1.attack();
        constable1.run();
        constable1.heal();
        constable1.decreaseHealth();
        constable1.increaseStamina();
        constable1.decreaseStamina();

        //HEADER
        System.out.println("\n");
        System.out.println("NEW WARRIOR");
        System.out.println("\n");

        //new warrior
        Warrior warrior1 = new Warrior();
        //set_value
        warrior1.set_values("Warrior John", 75, 100, 100, 50, 10);

        //print to console
        System.out.println("Name: " +  warrior1.name + "\n");
        System.out.println("Strength: " +  warrior1.strength + "\n");
        System.out.println("Health: " +  warrior1.health + "\n");
        System.out.println("Stamina: " +  warrior1.stamina + "\n");
        System.out.println("Speed: " +  warrior1.speed + "\n");
        System.out.println("Attack Power: " +  warrior1.attackPower + "\n");
        System.out.println("Shield Strength: " + warrior1.shieldStrength + "\n");

        //run methods
        System.out.println("\n" + "Running the new Warrior's methods: " + "\n");
        //warrior methods
        warrior1.decreaseShieldStrength();

        //normal methods
        constable1.attack();
        constable1.run();
        constable1.heal();
        constable1.decreaseHealth();
        constable1.increaseStamina();
        constable1.decreaseStamina();


    }
}
